#!/bin/bash

# 의심스러운 해시값 및 파일 배열
declare -A MALWARE_HASHES=(
["c7f693f7f85b01a8c0e561bd369845f40bff423b0743c7aa0f4c323d9133b5d4"]="hpasmmld"
["3f6f108db37d18519f47c5e4182e5e33cc795564f286ae770aa03372133d15c4"]="smartadm"
["95fd8a70c4b18a9a669fec6eb82dac0ba6a9236ac42a5ecde270330b66f51595"]="hald-addon-volume"
["aa779e83ff5271d3f2d270eaed16751a109eb722fca61465d86317e03bbf49e4"]="dbus-srv-bin.txt"
["925ec4e617adc81d6fcee60876f6b878e0313a11f25526179716a90c3b743173"]="dbus-srv"
["29564c19a15b06dd5be2a73d7543288f5b4e9e6668bbd5e48d3093fb6ddf1fdb"]="inode262394"
["be7d952d37812b7482c1d770433a499372fde7254981ce2e8e974a67f6a088b5"]="dbus-srv"
["027b1fed1b8213b86d8faebf51879ccc9b1afec7176e31354fbac695e8daf416"]="dbus-srv"
["a2ea82b3f5be30916c4a00a7759aa6ec1ae6ddadc4d82b3481640d8f6a325d59"]="dbus-srv"
["e04586672874685b019e9120fcd1509d68af6f9bc513e739575fc73edefd511d"]="File_in_Inode"
["adfdd11d69f4e971c87ca5b2073682d90118c0b3a3a9f5fbbda872ab1fb335c6"]="gm"
["7c39f3c3120e35b8ab89181f191f01e2556ca558475a2803cb1f02c05c830423"]="rad$"
)


check_files_by_hash() {
    gen_log "INFO: 파일 해시 검사 시작"
    local found_suspicious_file=false
    local SEARCH_PATHS=("/bin" "/sbin" "/usr/bin" "/usr/sbin" "/lib" "/usr/lib" "/etc" "/tmp" "/var/tmp" "/dev/shm" "/opt" "/home")

    for search_dir in "${SEARCH_PATHS[@]}"; do
        find "$search_dir" -type f -print0 2>/dev/null | while IFS= read -r -d $'\0' file_path; do
            [ ! -r "$file_path" ] && continue
            current_sha256=$(sha256sum "$file_path" 2>/dev/null | awk '{print $1}')
            [ -z "$current_sha256" ] && continue
            for hash_val in "${!MALWARE_HASHES[@]}"; do
                if [[ "$current_sha256" == "$hash_val" ]]; then
                    gen_log "CRITICAL: 의심 파일 발견 - ${MALWARE_HASHES[$hash_val]}"
                    gen_log "  경로: $file_path"
                    gen_log "  SHA256: $current_sha256"
                    found_suspicious_file=true
                fi
            done
        done
    done

    if [ "$found_suspicious_file" = false ]; then
        gen_log "INFO: 악성 해시와 일치하는 파일 없음."
    fi
}
